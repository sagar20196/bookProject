myApp.service("bookManage",function(){
    this.bookDetails=[
        {bookImg:'MyJourney.jpeg',bookId:101,bookName:'My Journey',bookAuthor:'Dr. A.P.J. Abdul Kalam Azad',bookIsbn:'BK0001234',bookPrice:'₹'+128,bookDescription:'From a small boy growing up in a remote town Rameswaram, to becoming the country\'s eleventh President, A.P.J. Abdul Kalam\'s life has been a tale of extraordinary determination, courage, perseverance and the desire to excel. It is a book that has different stories from his life weaved together.'},
        {bookImg:'bibw.jpg',bookId:102,bookName:'A Better India: A Better World',bookAuthor:'Narayana Murthy',bookIsbn:'BK001235',bookPrice:'₹'+450,bookDescription:'A Better India: A Better World brings together Narayana Murthy’s views on diverse issues -- from effective models of corporate and public governance to corporate social responsibility, from globalization and competing in a flat world to entrepreneurship and leadership challenges, from issues crucial to national development to good values and betterment of the education system. In A Better India: A Better World Narayana Murthy also unveils an ambitious blueprint for a vibrant, developed, egalitarian future that today’s youth must build tomorrow.'},
        {bookImg:'harrypotter.jpg',bookId:103,bookName:'Harry Potter',bookAuthor:'J.K.Rowling',bookIsbn:'BK0001236',bookPrice:'₹'+560,bookDescription:'Harry Potter is a series of seven fantasy novels written by British author J. K. Rowling. The novels chronicle the lives of a young wizard, Harry Potter, and his friends Hermione Granger and Ron Weasley, all of whom are students at Hogwarts School of Witchcraft and Wizardry.'},
        {bookImg:'jb.jpg',bookId:104,bookName:'Jungle Book',bookAuthor:'Rudyard Kipling',bookIsbn:'BK0001237',bookPrice:'₹'+250,bookDescription:'The Jungle Book by Rudyard Kipling is an adventure story about a man-cub named Mowgli. Mowgli is hunted by an evil tiger named Shere Khan. Mowgli tries to live a peaceful life with other humans, but is too wild for them and too human for the wolves. Eventually Mowgli finds a home in the jungle with a pack of his own.'},
        {bookImg:'tor.jpg',bookId:105,bookName:'Theory of Relativity',bookAuthor:'Albert Einstein',bookIsbn:'BK0001238',bookPrice:'₹'+1000,bookDescription:'Theory of Relativity is a novel about Dylan, who experiences homelessness after his mother kicks him out. ... Dylan learns how to survive on the street by avoiding dangerous people and finding other kids who are homeless like himself.' }];
    

this.getAllBookDetails=function()
{
    return this.bookDetails;
}
this.addBook=function(book)
{
    this.bookDetails.push(book);
}
this.deleteBook=function(book){
    var pos=this.bookDetails.findIndex(item=>{
        if(item.bookId == book.bookId)
        {
            return true;
        }
        else
        {
            return false;
        }
    })
    this.bookDetails.splice(pos,1);
}
})

