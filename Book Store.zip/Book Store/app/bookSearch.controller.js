myApp.controller("bookSearchController",function($scope,bookManage){
    $scope.bookSearchArr=bookManage.getAllBookDetails();
    $scope.deleteBookEventHandler=function(bookToBeDeleted)
    {
        bookManage.deleteBook(bookToBeDeleted);
    }
})