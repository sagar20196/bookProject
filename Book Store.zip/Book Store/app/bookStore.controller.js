myApp.controller("bookStoreController",function($scope) {
   $scope.bookArr =[
     {bookImg:'MyJourney.jpeg',bookId:101,bookName:'My Journey',bookAuthor:'Dr. A.P.J. Abdul Kalam Azad',bookIsbn:'BK0001234',bookPrice:128,bookDescription:[]},
     {bookImg:'bibw.jpg',bookId:102,bookName:'A Better India: A Better World',bookAuthor:'Narayana Murthy',bookIsbn:'BK001235',bookPrice:450,bookDescription:[]},
     {bookImg:'harrypotter.jpg',bookId:103,bookName:'Harry Potter',bookAuthor:'J.K.Rowling',bookIsbn:'BK0001236',bookPrice:560,bookDescription:[]},
     {bookImg:'jb.jpeg',bookId:104,bookName:'Jungle Book',bookAuthor:'Rudyard Kipling',bookIsbn:'BK0001237',bookPrice:250,bookDescription:[]},
     {bookImg:'tor.jpeg',bookId:105,bookName:'Theory of Relativity',bookAuthor:'Albert Einstein',bookIsbn:'BK0001238',bookPrice:1000,bookDescription:[] }];
     
    $scope.selectedbook={};
    $scope.bookdescription=false;
    $scope.bookDescriptionEventHandler =function(obj){
      $scope.selectedbook=obj;
      $scope.bookDescription=true;
    }
    $scope.bookDescription="";
    $scope.bookDescription=function(bookName){
      $scope.bookArr.forEach(element => {
        if(element.bookName == bookName)
          element.bookdescription.push($scope.bookdescription)

      });
      $scope.bookdescription="";
    }
    

})