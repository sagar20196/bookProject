myApp.controller("bookDisplayController",function($scope,bookManage){
    $scope.bookArr=bookManage.getAllBookDetails();
    $scope.showAddBook=false;
    $scope.showAddNewBookEventHandler=function(){
        $scope.showAddBook=true;
    }
    
})