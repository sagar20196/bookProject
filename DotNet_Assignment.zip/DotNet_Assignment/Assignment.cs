﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment_Day1
{
    class Book
    {
        public int BookId { get; set; }
        public string IsbnCode { get; set; }
        public string BookName { get; set; }
        public string Author { get; set; }
        public double Price { get; set; }
        public string Description { get; set; }
        public Book()
        {

        }
        public Book(int bookId, string bookName, string author, string isbnCode, double price, string description)
        {
            this.BookId = bookId;
            this.BookName = bookName;
            this.Author = author;
            this.IsbnCode = isbnCode;
            this.Price = price;
            this.Description = description;
        }

        public static List<Book> updateBook(List<Book> arr, int bookId)
        {
            Console.WriteLine();
            Console.WriteLine("Press 1 to edit Book Id");
            Console.WriteLine("Press 2 to edit Book name.");
            Console.WriteLine("Press 3 to edit Author name");
            Console.WriteLine("Press 4 to edit ISBN Code");
            Console.WriteLine("Press 5 to edit Price");
            Console.WriteLine("Press 6 For Exit");
            int n;
            do
            {
                Console.WriteLine();
                Console.WriteLine("Enter your choice you want to update in a given Book");
                n = Convert.ToInt32(Console.ReadLine());
                switch (n)
                {
                    case 1:
                        Console.WriteLine();
                        Console.WriteLine("Enter the new book id you want to update: ");
                        int bid = Convert.ToInt32(Console.ReadLine());
                        foreach (var item in arr)
                        {
                            if (item.BookId == bookId)
                            {
                                item.BookId = bid;
                            }
                        }
                        break;
                    case 2:
                        Console.WriteLine();
                        Console.WriteLine("Enter the new book name you want to update:");
                        string bname = Console.ReadLine();
                        foreach (var item in arr)
                        {
                            if (item.BookId == bookId)
                            {
                                item.BookName = bname;
                            }
                        }
                        break;
                    case 3:
                        Console.WriteLine();
                        Console.WriteLine("Enter the new author name you want to update:");
                        string aname = Console.ReadLine();
                        foreach (var item in arr)
                        {
                            if (item.BookId == bookId)
                            {
                                item.Author = aname;
                            }
                        }
                        break;
                    case 4:
                        Console.WriteLine();
                        Console.WriteLine("Enter the new ISBN code you want to update:");
                        string icode = Console.ReadLine();
                        foreach (var item in arr)
                        {
                            if (item.BookId == bookId)
                            {
                                item.IsbnCode = icode;
                            }
                        }
                        break;
                    case 5:
                        Console.WriteLine();
                        Console.WriteLine("Enter the new book name you want to update:");
                        double p = Convert.ToDouble(Console.ReadLine());
                        foreach (var item in arr)
                        {
                            if (item.BookId == bookId)
                            {
                                item.Price = p;
                            }
                        }
                        break;
                }
            } while (n != 6);
            ;
            return arr;
        }

        public static List<Book> showDescription(List<Book> arr, int bookId)
        {
            Console.WriteLine();
            Console.WriteLine("Enter the description of book you want to update:");
            string desc = Console.ReadLine();
            foreach (var item in arr)
            {
                if (item.BookId == bookId)
                {
                    item.Description = desc;
                }
            }
            return arr;
        }

        public static List<Book> addNewBBook(List<Book> bookArr)
        {
            Console.WriteLine("Enter the Book id:");
            int bid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Book name:");
            string bname = Console.ReadLine();
            Console.WriteLine("Enter the Author name:");
            string author = Console.ReadLine();
            Console.WriteLine("Enter the ISBN code:");
            string isbnCode = Console.ReadLine();
            Console.WriteLine("Enter the Price of a Book:");
            double price = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the Description of a Book");
            string desc = Console.ReadLine();
            Book b = new Book(bid,bname,author,isbnCode,price,desc);
            bookArr.Add(b);
            return bookArr;
        }

        public override string ToString()
        {
            return $"Book Id: {BookId}; Book Name: {BookName}; Author: {Author}; ISBN Code: {IsbnCode}; Price: {Price}; Description: {Description}";
        }
    }
    
    class Assignment2
    {
        public static int num;

        static void displayBook(List<Book> arr)
        {
            foreach (Book item in arr)
            {
                Console.WriteLine(item);
            }
        }
        static void Main(string[] args)
        {
            List<Book> bookArr = new List<Book>{
                new Book(101, "My Journey","Dr. A.P.J. Abdul Kalam","1234567890", 350.50," It is a book that has different stories from APJ Abdul Kalam life weaved together."),
                new Book(102, "A Better India: A Better World","Narayana Murthy","4567890123", 400,"It is a book which describes about the present scenario of the India."),
                new Book(103, "Jungle Book","Ruskin Bond","1284567890", 240,"It is a book which shows an adventure story about a man-cub named Mowgli."),
                new Book(104, "The Harry Potter series","J.K. Rowling","1294567890", 500,"It is a book which focus on Harry Potter, a boy who learns on his eleventh birthday that he is the orphaned son of two powerful wizards and possesses unique magical powers of his own."),
                new Book(105, "Theory of Relativity","Albert Einstein","1230567890", 600,"It is a book that describes the theory of gravity.")

            };

            //Book[] bookArr1 = new Book[]{
            //    new Book(101, "My Journey","Dr. A.P.J. Abdul Kalam","1234567890", 350.50),
            //    new Book(102, "A Better India: A Better World","Narayana Murthy","4567890123", 400),
            //    new Book(103, "Jungle Book","Ruskin Bond","1284567890", 240),
            //    new Book(104, "The Harry Potter series","J.K. Rowling","1294567890", 500),
            //    new Book(105, "Theory of Relativity","Albert Einstein","1230567890", 600)

            //};
            Console.WriteLine();

            //Func<List<Book>, int, Book> bookSearch = (arr, bId) => {


            //    return arr.Find(item => item.bookId == bId);
            //};
            //Book res = bookSearch(bookArr, bookId);
            //Console.WriteLine(res);

            Console.WriteLine("Press 1 : Edit Book Details");
            Console.WriteLine("Press 2 : Add New Book");
            Console.WriteLine("Press 3 : Delete Book");
            Console.WriteLine("Press 4 : Display Books");
            Console.WriteLine("Press 5 : Show Description");
            Console.WriteLine("Press 6 : Exit");
            do
            {
                Console.WriteLine();
                Console.WriteLine("Enter the number of your choice");
                num = Convert.ToInt32(Console.ReadLine());
                switch (num)
                {
                    case 1:
                        {
                            Func<List<Book>, int, Book> bookSearch = (arr, bId) =>
                            {
                                return arr.Find(item => item.BookId == bId);
                            };
                            Console.WriteLine("Enter the Book Id of Book you want to update");
                            int bookId = Convert.ToInt32(Console.ReadLine());
                            Book res1 = bookSearch(bookArr, bookId);
                            Console.WriteLine(res1);
                            var updatedBook = Book.updateBook(bookArr, bookId);
                            Console.WriteLine("Updated Book List");
                            foreach (var item in updatedBook)
                            {
                                Console.WriteLine(item);
                            }
                            break;
                        };
                    case 2:
                        var addedBook = Book.addNewBBook(bookArr);
                        foreach (var item in addedBook)
                        {
                            Console.WriteLine(item);
                        }
                        break;
                    case 3:
                        Console.WriteLine("Enter the Book Id of Book you want to remove:");
                        int id = Convert.ToInt32(Console.ReadLine());
                        bookArr.Remove(bookArr.Find(item => item.BookId == id));
                        foreach (var item in bookArr)
                        {
                            Console.WriteLine(item);
                        }
                        break;
                    case 4:
                        displayBook(bookArr);
                        break;
                    case 5:
                        Func<List<Book>, int, Book> bookSearchForDescription = (arr, bId) =>
                        {
                            return arr.Find(item => item.BookId == bId);
                        };
                        Console.WriteLine("Enter the Book Id of Book you want to update");
                        int bid = Convert.ToInt32(Console.ReadLine());
                        Book res2 = bookSearchForDescription(bookArr, bid);
                        Console.WriteLine(res2);
                        var showDesc = Book.showDescription(bookArr, bid);
                        foreach (var item in showDesc)
                        {
                            Console.WriteLine(item);
                        }
                        break;
                }
            } while (num != 6);
            ;
            Console.ReadLine();
        }

       
    }
}
